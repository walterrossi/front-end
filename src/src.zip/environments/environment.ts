// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'portfoliowr-2022',
    appId: '1:567439846605:web:7847d86893f03291260d84',
    storageBucket: 'portfoliowr-2022.appspot.com',
    apiKey: 'AIzaSyB9tw44OffzMP-oe_xmwQbkhwaVsscwRIc',
    authDomain: 'portfoliowr-2022.firebaseapp.com',
    messagingSenderId: '567439846605',
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
