export const environment = {
  firebase: {
    projectId: 'portfoliowr-2022',
    appId: '1:567439846605:web:7847d86893f03291260d84',
    storageBucket: 'portfoliowr-2022.appspot.com',
    apiKey: 'AIzaSyB9tw44OffzMP-oe_xmwQbkhwaVsscwRIc',
    authDomain: 'portfoliowr-2022.firebaseapp.com',
    messagingSenderId: '567439846605',
  },
  production: true
};
