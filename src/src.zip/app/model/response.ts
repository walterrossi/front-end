

export interface Response {
    status:string;
    resul:string;
}
