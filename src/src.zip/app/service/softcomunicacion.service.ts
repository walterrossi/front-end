import { Injectable } from '@angular/core';


import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class SoftcomunicacionService {
  URL= 'http://127.0.0.1:8080/mhardsoftcomunicacion/1';
  constructor(private http: HttpClient) { }
  public patch(URL:string, body:any){

    return this.http.patch(URL,body);
  }
}